package task04;

import java.util.ArrayList;
import java.util.Iterator;

public class App {

	public static void main(String[] args) {
		//Pizza pizzaObj = new Pizza("DRP-12345", "Füstölt sajtos", 3500, 40, false);
		//System.out.println(pizzaObj.isIdLenghtValid());
		
		PizzaFileDataUtil fileUtil = new PizzaFileDataUtil();
		ArrayList<Pizza> list = fileUtil.readPizzaDataFile();

		printPizzaList(list);
		ArrayList<Pizza> cheapest = PizzaListUtil.getLeastCheapestPizzasFromList(list);
		
		System.out.println("");
		System.out.println("Legolcsóbb pizza(k): ");
		cheapest.forEach(x->System.out.println(x));
	}
	
	private static void printPizzaList(ArrayList<Pizza> list ) {
		
		System.out.println("Az összes beolvasott pizza: ");
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			Pizza pizza = (Pizza) iterator.next();
			System.out.println(pizza.toString());
		}
	}

}
