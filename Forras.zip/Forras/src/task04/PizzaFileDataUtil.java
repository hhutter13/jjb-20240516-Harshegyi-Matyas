package task04;

import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class PizzaFileDataUtil {

	public ArrayList<Pizza> readPizzaDataFile(){
		ArrayList<Pizza> list = new ArrayList<Pizza>();
		
		try(
				FileReader fr = new FileReader(".\\task_04_data\\pizzeria.csv");
				BufferedReader br=new BufferedReader(fr))
		{
			
			String firstLine = br.readLine();
			String line;
			while((line=br.readLine())!=null) {
				String[] lineParts = line.split(";");
				
				String id = lineParts[0];
				String name = lineParts[1];
				int netPrice = Integer.parseInt(lineParts[2]);
				int soldNumber = Integer.parseInt(lineParts[3]);
				boolean sale = Integer.parseInt(lineParts[4]) == 1 ? true : false;
				
				list.add(new Pizza(id, name, netPrice, soldNumber, sale));
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return list;
	}
}
