package task04;

import java.util.ArrayList;
import java.util.Iterator;

public class PizzaListUtil {
	public static ArrayList<Pizza> getLeastCheapestPizzasFromList(ArrayList<Pizza> list) {
		list.sort((o1, o2) -> Integer.compare(o1.getNetPrice(), o2.getNetPrice()));
		Pizza cheapestPizza = list.get(0);
		
		ArrayList<Pizza> res= new ArrayList<Pizza>();
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			Pizza pizza = (Pizza) iterator.next();
			if(pizza.getNetPrice()==cheapestPizza.getNetPrice()) {
				res.add(pizza);
			}
		}
		return res;
	}
}
