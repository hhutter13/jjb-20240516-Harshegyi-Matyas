package task03;

import java.util.ArrayList;

public class PartListUtil {
	public static PcPart getMostExpensivePartFromList(ArrayList<PcPart> list) {
		list.sort((o1, o2) -> Integer.compare(o2.getNetPrice(), o1.getNetPrice()));
		PcPart mostExpensive = list.get(0);
		return mostExpensive;
	}
}
