package task03;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ReadPartsFromConsole {

	public ArrayList<PcPart> readPartsFromConsole() {
		ArrayList<PcPart> list = new ArrayList<PcPart>();;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		for (int i = 0; i < 3; i++) {
			int id = 0;
			String partName = null;
			String accessionNumber = null;
			String manufacturer = null;
			String model = null;
			int stockAmount = 0;
			int netPrice = 0;
			boolean available = false;
			
			try {
				System.out.print("Kérem a alkatrész azon.: ");
				id = Integer.parseInt(br.readLine());
				System.out.print("Kérem a alkatrész nevét: ");
				partName = br.readLine();
				System.out.print("Kérem a alkatrész leltárszámát: ");
				accessionNumber = br.readLine();
				System.out.print("Kérem a alkatrész gyártót: ");
				manufacturer = br.readLine();
				System.out.print("Kérem a alkatrész modelt: ");
				model = br.readLine();
				
				System.out.print("Kérem a alkatrész raktármennyiség: ");
				stockAmount = Integer.parseInt(br.readLine());
				System.out.print("Kérem a alkatrész nettó ár: ");
				netPrice = Integer.parseInt(br.readLine());
				System.out.print("Kérem , hogy az alkatrész elérhető [y,n]: ");
				available = br.readLine().compareTo("y") == 0 ? true: false;
				
				PcPart pcPartObject = new PcPart(
						id,
						partName,
						accessionNumber,
						manufacturer,
						model,
						stockAmount,
						netPrice,
						available
				);
				list.add(pcPartObject);				
				
			}catch (Exception e) {
				e.printStackTrace();
			}
		}		
		
		return list;
	}
}
