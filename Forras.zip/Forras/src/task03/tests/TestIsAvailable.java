package task03.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import task03.PartListUtil;
import task03.PcPart;

public class TestIsAvailable {

	@Test
	public void isAvailableSetFalse() {
		PcPart pcPartObject = new PcPart(
				1,
				"ASUS alaplap R400",
				"TGO-120401",
				"ASUS",
				"R400",
				0,
				35000,
				false
		);
		boolean actual = pcPartObject.isAvailable();
		boolean expected = false;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testModelName() {
		PcPart pcPartObject = new PcPart(
				1,
				"ASUS alaplap R400",
				"TGO-120401",
				"ASUS",
				"R400",
				0,
				35000,
				false
		);
		String actual = pcPartObject.getModel();
		String expected = "R400";
		assertEquals(expected, actual);
	}
	
	@Test
	public void testMostExpensiveFromList() {
		ArrayList<PcPart> list = new ArrayList<PcPart>();
		
		PcPart pcPartObject1 = new PcPart(
				1,
				"ASUS alaplap R400",
				"TGO-120401",
				"ASUS",
				"R400",
				0,
				35000,
				false
		);
		PcPart pcPartObject2 = new PcPart(
				2,
				"ASUS alaplap R402",
				"TGO-120402",
				"ASUS",
				"R402",
				23,
				45000,
				true
		);
		PcPart pcPartObject3 = new PcPart(
				3,
				"ASUS alaplap R403",
				"TGO-12043",
				"ASUS",
				"R403",
				8,
				17000,
				true
		);
		PcPart pcPartObject4 = new PcPart(
				4,
				"ASUS alaplap R404",
				"TGO-120404",
				"ASUS",
				"R404",
				0,
				38000,
				false
		);
		PcPart pcPartObject5 = new PcPart(
				5,
				"ASUS alaplap R405",
				"TGO-120401",
				"ASUS",
				"R405",
				10,
				25000,
				true
		);
		
		list.add(pcPartObject1);
		list.add(pcPartObject2);
		list.add(pcPartObject3);
		list.add(pcPartObject4);
		list.add(pcPartObject5);
		
		PcPart mostExpensivePcPartObject = PartListUtil.getMostExpensivePartFromList(list);
		int actual = mostExpensivePcPartObject.getNetPrice();
		int expected = 45000;
		assertEquals(expected, actual);
	}
}
