package task03;

import java.util.ArrayList;

public class App {

	public static void main(String[] args) {

	
		/*PcPart pcPartObject = new PcPart(
				1,
				"ASUS alaplap R400",
				"TGO-120401",
				"ASUS",
				"R400",
				30,
				35000,
				true
		);*/

		ReadPartsFromConsole read = new ReadPartsFromConsole();
		ArrayList<PcPart> list = read.readPartsFromConsole();
		
		printOutAllParts(list);
		printMostExpensivePart(list);
		
	}
	
	private static void printOutAllParts(ArrayList<PcPart> list) {
		System.out.println("Az összes alkatrész: ");
		list.forEach(x -> System.out.println(x));
		System.out.println();
	}
	
	
	private static void printMostExpensivePart(ArrayList<PcPart> list) {
		System.out.println("A legdrágább alkatrész: ");
		System.out.println(PartListUtil.getMostExpensivePartFromList(list));
	}

}
