package task01.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import task01.GenerateUserName;
import task01.User;

public class TestGenerateUserName {

	@Test
	public void testUserNameGeneteFirstPart() {
		User userObj = new User("ELek", "Teszt");
		GenerateUserName generateUserNameObj = new GenerateUserName();
		generateUserNameObj.generateUserName(userObj);
		String expected = "TEele";
		String actual = userObj.getUserName().substring(0,5);
		assertEquals(expected, actual);
	}
	
	@Test
	public void testUserNameContainsSnake() {
		User userObj = new User("ELek", "Teszt");
		GenerateUserName generateUserNameObj = new GenerateUserName();
		generateUserNameObj.generateUserName(userObj);
		assertTrue(userObj.getUserName().contains("_"));
	}
	
	@Test
	public void testUserNameGeneteLastnamePart() {
		User userObj = new User("ELek", "Lastname");
		GenerateUserName generateUserNameObj = new GenerateUserName();
		generateUserNameObj.generateUserName(userObj);
		String expected = "LA";
		String actual = userObj.getUserName().substring(0,2);
		assertEquals(expected, actual);
	}
	
	@Test
	public void testUserNameGeneteRandomPart() {
		User userObj = new User("ELek", "Teszt");
		GenerateUserName generateUserNameObj = new GenerateUserName();
		generateUserNameObj.generateUserName(userObj, new int[] {1,1});
		int expected = 1;
		String actual = userObj.getUserName().substring(6);
		assertEquals(expected, Integer.parseInt(actual));
	}
	
}
