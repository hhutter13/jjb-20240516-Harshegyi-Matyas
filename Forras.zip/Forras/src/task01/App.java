package task01;

public class App {

	public static void main(String[] args) {

		ReadDataFromConsole readUserDataObj = new ReadDataFromConsole();
		User userObj = readUserDataObj.getUserData();
		int[] rInterval = readUserDataObj.readRandomInterval();
		GenerateUserName generateUserNameObj = new GenerateUserName();
		generateUserNameObj.generateUserName(userObj, rInterval);
		System.out.println(userObj.toString());
	}

}
