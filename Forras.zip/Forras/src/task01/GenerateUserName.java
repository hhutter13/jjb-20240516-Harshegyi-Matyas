package task01;

import java.util.Random;

public class GenerateUserName {
	
	public void generateUserName(User userObj) {
		this.generateUserName(userObj, new int[]{1,100});
	}

	public void generateUserName(User userObj, int[] rInterval) {
		String userName2 = userObj.getLastName().substring(0,2).toUpperCase() + 
				userObj.getFirstName().substring(0,3).toLowerCase();
		userName2 +="_";
		Random r = new Random();
		//userName2 += r.nextInt(100)+1;
		userName2 += r.nextInt(rInterval[1]) + rInterval[0];
		userObj.setUserName(userName2);
	}
}
