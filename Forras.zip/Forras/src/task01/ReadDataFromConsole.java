package task01;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class ReadDataFromConsole {

	@SuppressWarnings("unused")
	public User getUserData() {
		
		String firstName = null;
		String lastName = null;
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("Kérem adja meg a vezetéknevét: ");
			lastName = br.readLine();
			System.out.print("Kérem adja meg a keresztnevét: ");
			firstName = br.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		User userObj = new User(firstName, lastName);
		return userObj;
	}
	
	public int[] readRandomInterval(){
		int[] interval = new int[2];
		String line;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		boolean minIsValid = false;
		do {
			try {
				System.out.print("Kérem adja meg a random intervallum min. értékét: ");
				line = br.readLine();
				try {
					interval[0] = Integer.parseInt(line);
				}catch(NumberFormatException e) {
					System.out.print("Hibás input! ");
				}
				minIsValid = true;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}while(!minIsValid);
			
		boolean maxIsValid = false;
		do {
			try {
				System.out.print("Kérem adja meg a random intervallum max. értékét: ");
				line = br.readLine();
				try {
					interval[1] = Integer.parseInt(line);
				}catch(NumberFormatException e) {
					System.out.print("Hibás input! ");
				}
				maxIsValid = true;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}while(!maxIsValid);
		
		return interval;
	}
}
