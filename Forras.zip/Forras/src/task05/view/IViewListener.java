package task05.view;

public interface IViewListener {
	
	public void onButtonClickedCreateFrame();
	public void onButtonClickedSaveEstate();
	public void onButtonClickedCloseEstateNewFrame();
}
