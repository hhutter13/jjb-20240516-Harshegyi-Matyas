package task05.view;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import task05.model.Estate;

public class View {
	
	private final ArrayList<IViewListener> listeners;
	private JScrollPane scrollPane;
	private JTable tableEstate;
	private JFrame estateListFrame;

	public View() {
		estateListFrame = new JFrame();
		estateListFrame.setBounds(300, 200, 1020, 650);
		estateListFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		estateListFrame.getContentPane().setLayout(null);
		estateListFrame.setTitle("Ingatlan nyilvántartás");
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(35,21,921,180);
		estateListFrame.getContentPane().add(scrollPane);
		
		tableEstate = new JTable();
		scrollPane.setViewportView(tableEstate);
	
		this.listeners = new ArrayList<IViewListener>();
		estateListFrame.setVisible(true);
	}
	
	public void addListener(final IViewListener listener) {
		listeners.add(listener);
	}
	
	public void setTableCellCenter() {
		DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
		renderer.setHorizontalAlignment(JLabel.CENTER);
		for (int i = 0; i < tableEstate.getColumnCount(); i++) {
			tableEstate.getColumnModel().getColumn(i).setCellRenderer(renderer);
		}
	}
	
	public void setModelToTableEmployee(List<Estate> estates) {
		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("Id");
		model.addColumn("Név");
		model.addColumn("Méret");
		model.addColumn("Cím");
		model.addColumn("Ár (MFt)");
		model.addColumn("Akciós");
		model.addColumn("Állapot");
		
		for (Estate estate : estates) {
			model.addRow(new Object[] {
					estate.getId(), 
					estate.getName(),
					estate.getSize(), 
					estate.getAddressPostalNumber() + ", "+estate.getAddressCity() + ", "+estate.getAddress(), 
					estate.getPrice(),
					estate.getSaleText(),
					estate.getStatusText()
			});
		}
		tableEstate.setModel(model);
		tableEstate.setRowHeight(30);
		setTableCellCenter();
	}
	
}
