package task05.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import task05.model.Estate;
import task05.utils.Database;

public class EstateDao implements ICrudEstateDao{

	private Connection con = new Database().createConnection();
	private ResultSet rs = null;
	private PreparedStatement pstmt = null; 
	
	@Override
	public List<Estate> getAll() {
		List<Estate> estates = new ArrayList<Estate>();
		String sql = "SELECT * FROM estate as e"
				+ " INNER JOIN estate_category as ec ON"
				+ " e.category_id = ec.id ORDER BY e.id;"; 
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				estates.add(getObjectFromRs(rs));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return estates;
	}

	@Override
	public Object getById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Estate getObjectFromRs(ResultSet rs) {
		Estate estateObj = null;
		try {
			estateObj = new Estate(
					rs.getInt("id"),
					rs.getString("name"),
					rs.getInt("size"),
					rs.getInt("room_count"),
					rs.getString("address_city"),
					rs.getString("address_postal_number"),
					rs.getString("address"),
					rs.getInt("price"),
					rs.getInt("category_id"),
					rs.getBoolean("sale"),
					rs.getBoolean("status")
			);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return estateObj;
	}

	@Override
	public void save(Estate estateObj) {
		// TODO Auto-generated method stub
		
	}
}
