package task02;

import task02.ReadBicycleDataFromConsole;

public class App {

	public static void main(String[] args) {
		ReadBicycleDataFromConsole readDataObj = new ReadBicycleDataFromConsole();
		Bicycle bicycleObj = readDataObj.getBicycleData();
		int saleNetPricePercent = readDataObj.getBicycleSaleNetPriceValue();
		bicycleObj.setSaleNetPrice(saleNetPricePercent);
		//System.out.printf("Kerékpár akciós százalékos értéke: %d%%\n", saleNetPricePercent);
		System.out.println(bicycleObj.toString());
	}
}
