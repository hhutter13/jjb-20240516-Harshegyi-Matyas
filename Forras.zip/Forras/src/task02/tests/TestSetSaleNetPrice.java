package task02.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import task02.Bicycle;

public class TestSetSaleNetPrice {

	@Test
	public void testSetSaleNetPriceCalculate() {
		Bicycle bicycleObj = new Bicycle(1, "GIANT", "G-1000", 100000, true);
		bicycleObj.setSaleNetPrice(20);
		double actual = bicycleObj.getNetPrice();
		double expected = 80000;	
		assertEquals(expected, actual);
	}
	
	@Test
	public void testManufacturerName() {
		Bicycle bicycleObj = new Bicycle(1, "GIANT", "G-1000", 100000, true);
		bicycleObj.setSaleNetPrice(20);
		String actual = bicycleObj.getManufacturer();
		String expected = "GIANT";	
		assertEquals(expected, actual);
	}
	
	@Test
	public void testModelName() {
		Bicycle bicycleObj = new Bicycle(1, "GIANT", "G-1000", 100000, true);
		bicycleObj.setSaleNetPrice(20);
		String actual = bicycleObj.getModel();
		String expected = "G-1000";	
		assertEquals(expected, actual);
	}
}
