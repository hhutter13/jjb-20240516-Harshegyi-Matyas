package task02;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class ReadBicycleDataFromConsole {

	public Bicycle getBicycleData() {
		int id = 0;
		String manufacturer = null;
		String model = null;
		int netPrice = 0;
		boolean available = false;

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("Kérem a kerékpár id-t: ");
			id = Integer.parseInt(br.readLine());
			System.out.print("Kérem a kerékpár gyártóját: ");
			manufacturer = br.readLine();
			System.out.print("Kérem a kerékpár modeljét: ");
			model = br.readLine();
			System.out.print("Kérem a kerékpár nettó árát: ");
			netPrice = Integer.parseInt(br.readLine());
			System.out.print("Kérem a kerékpár elérhető-e [y, n]: ");
			available = br.readLine().compareTo("y") == 0 ? true : false;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return new Bicycle(id, manufacturer, model, netPrice, available);
	}
	
	public int getBicycleSaleNetPriceValue() {
		int percent = 0;
		
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("Kérem a kerékpár akciós százalékos mértékét: ");
			percent = Integer.parseInt(br.readLine());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return percent;
	}
}
